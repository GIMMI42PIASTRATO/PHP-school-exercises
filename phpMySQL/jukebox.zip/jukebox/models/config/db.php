<?php
$host = "localhost";
$dbname = "BUSSANOVITTORIO";
$username = "root";
$password = "12345678";
