<?php

require_once __DIR__ . "/../models/UserModel.php";

class UserController {
    public static function getUserById()
}